# Survei Validasi Relasi Lintas-Buku (Cross-Book Completion)

**117 relasi** untuk divalidasi (confidence >= 0.5; 8 relasi confidence rendah dikeluarkan dari survei utama).

## Cara menilai setiap relasi

Untuk setiap baris **A —[RELASI]→ B**, nilai 3 aspek:

1. **Relasi valid?** — Apakah konsep A dan B benar-benar berkaitan? (Ya/Tidak)
2. **Tipe relasi benar?** — Apakah label relasi yang diusulkan tepat? (Benar/Salah; jika salah, tulis tipe yang benar)
3. **Arah benar?** — Apakah arah A→B sudah benar? (Benar/Terbalik/NA untuk relasi simetris)
4. **Komentar** (opsional).

## Lima tipe relasi

- **SAMA_DENGAN (konsep yang sama di buku berbeda)**
- **PRASYARAT_UNTUK (A prasyarat memahami B)**
- **APLIKASI_DARI (A penerapan konsep B di disiplin lain)**
- **MEMPERDALAM (A memperdalam pemahaman B)**
- **BERKAITAN_DENGAN (berkaitan umum)**

## Distribusi

| Pasangan Mapel | Jumlah |
|---|--:|
| Biologi <-> Kimia | 91 |
| Fisika <-> Kimia | 21 |
| Biologi <-> Fisika | 5 |

| Tipe Relasi | Jumlah |
|---|--:|
| PRASYARAT_UNTUK | 57 |
| MEMPERDALAM | 31 |
| APLIKASI_DARI | 15 |
| BERKAITAN_DENGAN | 13 |
| SAMA_DENGAN | 1 |

## Daftar relasi (per pasangan mapel)

### Biologi <-> Fisika

| ID | Konsep A (mapel) | Relasi diusulkan | Konsep B (mapel) | Penjelasan |
|---|---|---|---|---|
| LB003 | Energi Aktivasi (Biologi) | **BERKAITAN_DENGAN** | Fungsi Kerja Logam (W0) (Fisika) | Kedua konsep ini berkaitan dengan ide energi ambang minimum yang diperlukan untuk memulai suatu proses, meskipun dalam konteks yang berbeda. |
| LB021 | Fotoelektron (Fisika) | **BERKAITAN_DENGAN** | Fotosintesis (Biologi) | Kedua konsep ini berkaitan dengan interaksi cahaya dan elektron, namun dalam konteks dan mekanisme yang sangat berbeda antara fisika dan biologi. |
| LB060 | Efek Fotolistrik (Fisika) | **MEMPERDALAM** | Fotosintesis (Biologi) | Efek fotolistrik memperdalam pemahaman bagaimana energi cahaya memicu pergerakan elektron, relevan dengan inisiasi fotosintesis. |
| LB112 | Ilmu Pendukung Bioteknologi (Biologi) | **BERKAITAN_DENGAN** | Pemanfaatan Gelombang Mikro (Fisika) | Konsep A menyebut fisika sebagai ilmu pendukung bioteknologi, dan konsep B adalah salah satu aplikasi spesifik dari fisika yang secara umum dapat berkaitan dengan inovasi bioteknologi. |
| LB113 | Foton (Fisika) | **MEMPERDALAM** | Fotosintesis (Biologi) | Konsep foton dari fisika memperdalam pemahaman tentang bagaimana energi cahaya diserap dan digunakan dalam fotosintesis. |

### Biologi <-> Kimia

| ID | Konsep A (mapel) | Relasi diusulkan | Konsep B (mapel) | Penjelasan |
|---|---|---|---|---|
| LB001 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Penyuntingan Genom (Genome Editing) (Biologi) | Pemahaman struktur kimia DNA (Kimia) adalah prasyarat untuk memahami mekanisme penyuntingan genom (Biologi). |
| LB002 | Gugus Fungsi (Kimia) | **PRASYARAT_UNTUK** | Holoenzim (Biologi) | Pemahaman tentang gugus fungsi (Kimia) adalah prasyarat untuk memahami sifat kimia gugus prostetik yang esensial dalam holoenzim (Biologi). |
| LB004 | Protein (Kimia) | **MEMPERDALAM** | Translasi (Biologi) | Konsep protein (Kimia) memperdalam pemahaman tentang translasi (Biologi) dengan menjelaskan struktur dan fungsi produk akhir yang dihasilkan oleh proses tersebut. |
| LB006 | Elektrode (Kimia) | **MEMPERDALAM** | Fosforilasi Oksidatif (Biologi) | Konsep elektrode dalam kimia, yang melibatkan transfer elektron dan reaksi redoks, memperdalam pemahaman tentang transpor elektron dalam fosforilasi oksidatif biologi. |
| LB007 | Respirasi Seluler (Biologi) | **MEMPERDALAM** | Sel Volta (Kimia) | Prinsip konversi energi kimia melalui reaksi redoks pada Sel Volta (Kimia) memperdalam pemahaman mekanisme pembentukan energi dalam Respirasi Seluler (Biologi). |
| LB009 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Kromosom (Biologi) | Pemahaman DNA (Kimia) sebagai penyusun utama adalah prasyarat untuk memahami struktur dan fungsi kromosom (Biologi). |
| LB010 | Polimer Sintetik (Kimia) | **BERKAITAN_DENGAN** | Sintesis Protein (Biologi) | Kedua konsep ini berkaitan dengan pembentukan molekul besar (polimer) dari unit-unit kecil, meskipun satu adalah buatan manusia dan yang lain adalah proses biologis. |
| LB011 | Fosforilasi Oksidatif (Biologi) | **MEMPERDALAM** | Reaksi Reduksi Senyawa Organik (Kimia) | Pemahaman reaksi reduksi senyawa organik dari kimia memperdalam pemahaman tentang peran NADH dan FADH2 sebagai pembawa elektron tereduksi dalam fosforilasi oksidatif. |
| LB012 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Translasi (Biologi) | Pemahaman asam amino sebagai monomer protein adalah prasyarat untuk memahami produk dan mekanisme proses translasi. |
| LB015 | Fosforilasi Oksidatif (Biologi) | **PRASYARAT_UNTUK** | Reduksi (Kimia) | Pemahaman konsep Reduksi (Kimia) sangat penting sebagai prasyarat untuk memahami proses transpor elektron dalam Fosforilasi Oksidatif (Biologi). |
| LB018 | Monomer (Kimia) | **PRASYARAT_UNTUK** | Translasi (Biologi) | Konsep monomer dari kimia adalah prasyarat untuk memahami bagaimana translasi membentuk polipeptida dari unit-unit asam amino. |
| LB019 | Bilangan Oksidasi (Kimia) | **PRASYARAT_UNTUK** | Fosforilasi Oksidatif (Biologi) | Konsep bilangan oksidasi (Kimia) adalah prasyarat untuk memahami perubahan redoks molekuler yang terjadi selama fosforilasi oksidatif (Biologi). |
| LB020 | Enzim (Biologi) | **PRASYARAT_UNTUK** | Gugus Fungsi (Kimia) | Pemahaman gugus fungsi dalam Kimia adalah prasyarat untuk memahami mekanisme kerja dan interaksi enzim di Biologi. |
| LB023 | Nukleotida (Kimia) | **PRASYARAT_UNTUK** | Translasi (Biologi) | Pemahaman nukleotida sebagai penyusun mRNA adalah prasyarat untuk memahami bagaimana mRNA berfungsi sebagai cetakan translasi. |
| LB024 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **MEMPERDALAM** | Replikasi DNA (Biologi) | Pemahaman DNA dari sudut pandang kimia memperdalam pengertian tentang mekanisme replikasi DNA secara biologis. |
| LB025 | Holoenzim (Biologi) | **MEMPERDALAM** | Koagulasi (Kimia) | Konsep koagulasi dari Kimia memperdalam pemahaman tentang bagaimana kerusakan struktur protein enzim (holoenzim) dapat terjadi di Biologi. |
| LB027 | Biodegradable Plastic (Kimia) | **APLIKASI_DARI** | Biodegradasi (Biologi) | Biodegradable Plastic adalah jenis material yang dirancang untuk mengalami proses Biodegradasi, sebuah konsep biologis tentang penguraian bahan organik. |
| LB029 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Mitosis (Biologi) | Pemahaman struktur kimia DNA (Kimia) adalah prasyarat untuk memahami bagaimana materi genetik tersebut direplikasi dan didistribusikan selama mitosis (Biologi). |
| LB030 | Energi Aktivasi (Biologi) | **PRASYARAT_UNTUK** | Reaksi Elektrokimia (Kimia) | Konsep Energi Aktivasi dalam biologi (dan kimia umum) adalah prasyarat untuk memahami mengapa Reaksi Elektrokimia memerlukan energi untuk memulai atau berlangsung. |
| LB031 | DNA (Deoxyribonucleic Acid) (Biologi) | **APLIKASI_DARI** | Nukleotida (Kimia) | Konsep DNA dalam biologi merupakan penerapan dari konsep nukleotida kimia sebagai unit penyusun dasarnya. |
| LB032 | Polimer (Kimia) | **PRASYARAT_UNTUK** | Translasi (Biologi) | Konsep Polimer (Kimia) adalah prasyarat untuk memahami produk Translasi (Biologi) yaitu polipeptida, yang merupakan jenis polimer. |
| LB033 | Fosforilasi Oksidatif (Biologi) | **PRASYARAT_UNTUK** | Reaksi Redoks (Kimia) | Konsep reaksi redoks (Kimia) adalah prasyarat untuk memahami mekanisme transfer elektron dan produksi energi dalam fosforilasi oksidatif (Biologi). |
| LB034 | Enzim (Biologi) | **APLIKASI_DARI** | Protein (Kimia) | Enzim dalam biologi adalah salah satu jenis Protein, yang merupakan makromolekul organik yang dipelajari dalam kimia. |
| LB035 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Kode Genetik (Biologi) | Pemahaman tentang asam amino dari Kimia adalah prasyarat untuk memahami bagaimana kode genetik menentukan urutan asam amino dalam protein. |
| LB036 | Fosforilasi Oksidatif (Biologi) | **MEMPERDALAM** | Reaksi Oksidasi Senyawa Organik (Kimia) | Konsep reaksi oksidasi senyawa organik (Kimia) memperdalam pemahaman tentang mekanisme kimiawi yang mendasari fosforilasi oksidatif (Biologi). |
| LB037 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Kode Genetik (Biologi) | Pemahaman struktur DNA adalah prasyarat untuk memahami bagaimana kode genetik disimpan dan diekspresikan. |
| LB038 | Hidrokarbon (Kimia) | **PRASYARAT_UNTUK** | Teori Evolusi Kimia (Biologi) | Konsep hidrokarbon dari Kimia adalah prasyarat untuk memahami jenis senyawa organik awal yang terlibat dalam Teori Evolusi Kimia di Biologi. |
| LB039 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **BERKAITAN_DENGAN** | Enzim (Biologi) | DNA (Kimia) adalah cetak biru genetik yang mengkodekan informasi untuk sintesis enzim (Biologi), dan enzim berperan penting dalam proses yang melibatkan DNA. |
| LB040 | Enzim Fermentasi (Biologi) | **PRASYARAT_UNTUK** | Protein (Kimia) | Pemahaman tentang protein dari Kimia adalah prasyarat untuk memahami struktur dan fungsi enzim fermentasi dalam Biologi. |
| LB041 | Inhibitor Enzim (Biologi) | **PRASYARAT_UNTUK** | Isomer (Kimia) | Konsep isomer dari Kimia adalah prasyarat untuk memahami bagaimana bentuk molekul inhibitor enzim di Biologi mempengaruhi interaksinya dengan enzim. |
| LB042 | Kode Genetik (Biologi) | **PRASYARAT_UNTUK** | Protein (Kimia) | Pemahaman kode genetik adalah prasyarat untuk memahami bagaimana urutan asam amino dalam protein ditentukan. |
| LB043 | Nukleotida (Kimia) | **PRASYARAT_UNTUK** | Transkripsi (Biologi) | Pemahaman tentang nukleotida (Kimia) adalah prasyarat untuk memahami bagaimana unit-unit ini dirangkai selama proses transkripsi (Biologi). |
| LB044 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Sintesis Protein (Biologi) | Konsep asam amino dari kimia adalah prasyarat fundamental untuk memahami proses sintesis protein dalam biologi, karena asam amino adalah unit pembangun protein. |
| LB045 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Kromosom (Biologi) | Asam amino adalah monomer penyusun protein histon, yang merupakan komponen kromosom; pemahaman Kimia adalah prasyarat Biologi. |
| LB046 | Respirasi Seluler (Biologi) | **MEMPERDALAM** | ggl sel (Kimia) | Konsep ggl sel dalam Kimia dapat memperdalam pemahaman tentang transfer elektron dan produksi energi dalam proses respirasi seluler di Biologi. |
| LB047 | Protein (Kimia) | **PRASYARAT_UNTUK** | Transkripsi (Biologi) | Pemahaman tentang protein (Kimia) adalah prasyarat untuk memahami peran enzim RNA polimerase (protein) dalam proses transkripsi (Biologi). |
| LB048 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Kemiripan DNA (Biologi) | Pemahaman struktur DNA dari Kimia adalah prasyarat untuk memahami konsep kemiripan DNA dan implikasinya dalam Biologi. |
| LB050 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Dogma Sentral Biologi (Biologi) | Pemahaman struktur DNA dari Kimia adalah prasyarat untuk memahami peran DNA dalam aliran informasi genetik pada Dogma Sentral Biologi. |
| LB051 | Materi Genetik (Biologi) | **PRASYARAT_UNTUK** | Nukleotida (Kimia) | Pemahaman tentang Nukleotida sebagai monomer penyusun DNA dalam Kimia adalah prasyarat untuk memahami Materi Genetik yang meliputi DNA dalam Biologi. |
| LB052 | Kode Genetik (Biologi) | **APLIKASI_DARI** | Nukleotida (Kimia) | Konsep kode genetik dalam biologi merupakan penerapan dari konsep nukleotida kimia sebagai dasar pengkodean informasi. |
| LB053 | Inhibitor Enzim (Biologi) | **PRASYARAT_UNTUK** | Protein (Kimia) | Pemahaman tentang Protein (Kimia) sebagai makromolekul dasar adalah prasyarat untuk memahami Enzim dan Inhibitor Enzim (Biologi). |
| LB054 | Polimer Alam (Biopolimer) (Kimia) | **MEMPERDALAM** | Translasi (Biologi) | Konsep polimer alam (biopolimer) dari kimia memperdalam pemahaman bahwa polipeptida yang dihasilkan translasi adalah jenis protein. |
| LB055 | Protein (Kimia) | **PRASYARAT_UNTUK** | Teori Induced Fit (Biologi) | Pemahaman protein sebagai makromolekul kimia adalah prasyarat untuk memahami mekanisme kerja enzim yang dijelaskan oleh Teori Induced Fit. |
| LB056 | Enzim (Biologi) | **BERKAITAN_DENGAN** | Unit Ulang Monomer (Kimia) | Enzim adalah polimer (protein) yang tersusun dari unit ulang monomer (asam amino), sehingga konsep ini berkaitan secara struktural. |
| LB057 | Kromosom (Biologi) | **MEMPERDALAM** | Protein (Kimia) | Konsep protein dalam Kimia memperdalam pemahaman tentang protein histon sebagai komponen struktural kromosom dalam Biologi. |
| LB058 | Kromosom (Biologi) | **PRASYARAT_UNTUK** | Nukleotida (Kimia) | Nukleotida (Kimia) adalah monomer penyusun DNA, yang merupakan komponen utama kromosom (Biologi), menjadikannya prasyarat fundamental. |
| LB059 | Gugus Fungsi (Kimia) | **PRASYARAT_UNTUK** | Inhibitor Enzim (Biologi) | Pemahaman gugus fungsi dari Kimia adalah prasyarat untuk memahami bagaimana inhibitor enzim di Biologi berinteraksi dengan enzim pada tingkat molekuler. |
| LB062 | Enzim Fermentasi (Biologi) | **APLIKASI_DARI** | Etanol (Kimia) | Enzim fermentasi di Biologi adalah agen biologis yang mengkatalisis produksi etanol, sebuah senyawa kimia. |
| LB064 | Fosforilasi Oksidatif (Biologi) | **MEMPERDALAM** | Sel Volta (Kimia) | Prinsip konversi energi kimia melalui reaksi redoks pada Sel Volta (Kimia) memperdalam pemahaman mekanisme Fosforilasi Oksidatif (Biologi). |
| LB065 | Protein (Kimia) | **PRASYARAT_UNTUK** | Sintesis Protein (Biologi) | Pemahaman tentang struktur dan komposisi kimia protein (Kimia) adalah prasyarat untuk memahami proses biologis sintesisnya (Biologi). |
| LB066 | Fotosintesis (Biologi) | **MEMPERDALAM** | Monosakarida (Kimia) | Pemahaman tentang monosakarida seperti glukosa dari sudut pandang kimia memperdalam pemahaman tentang produk utama yang dihasilkan dalam proses fotosintesis. |
| LB067 | Fosforilasi Oksidatif (Biologi) | **MEMPERDALAM** | Reaksi Elektrokimia (Kimia) | Prinsip Reaksi Elektrokimia (Kimia) yang melibatkan transfer elektron dan konversi energi memperdalam pemahaman Fosforilasi Oksidatif (Biologi). |
| LB068 | Fotosintesis (Biologi) | **MEMPERDALAM** | Pati (Kimia) | Fotosintesis (Biologi) menjelaskan proses biologis yang menghasilkan glukosa, yang kemudian disimpan sebagai pati (Kimia), sehingga memperdalam pemahaman tentang asal pati. |
| LB069 | Metabolisme (Biologi) | **BERKAITAN_DENGAN** | Reaksi Elektrokimia (Kimia) | Metabolisme melibatkan berbagai reaksi kimia dan perubahan energi dalam sel, yang dapat berkaitan dengan prinsip-prinsip reaksi elektrokimia dalam konteks transfer elektron. |
| LB070 | Energi Aktivasi (Biologi) | **PRASYARAT_UNTUK** | Reaksi Polimerisasi (Kimia) | Konsep energi aktivasi adalah prasyarat untuk memahami reaksi polimerisasi, karena setiap reaksi kimia membutuhkan energi aktivasi untuk dimulai. |
| LB071 | Fotosintesis (Biologi) | **MEMPERDALAM** | Selulosa (Kimia) | Konsep selulosa dari kimia memperdalam pemahaman tentang salah satu produk akhir dari glukosa hasil fotosintesis. |
| LB073 | Holoenzim (Biologi) | **PRASYARAT_UNTUK** | Protein (Kimia) | Pemahaman tentang protein dari Kimia adalah prasyarat untuk memahami komponen protein (apoenzim) dalam struktur holoenzim di Biologi. |
| LB075 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Mutasi (Biologi) | Pemahaman struktur kimia DNA dari Kimia adalah prasyarat fundamental untuk memahami konsep mutasi sebagai perubahan pada materi genetik dalam Biologi. |
| LB077 | Oksidasi (Kimia) | **MEMPERDALAM** | Siklus Krebs (Biologi) | Konsep oksidasi dari Kimia memberikan dasar kimia yang memperdalam pemahaman tentang reaksi redoks yang terjadi dalam Siklus Krebs di Biologi. |
| LB078 | Reaksi Polimerisasi (Kimia) | **PRASYARAT_UNTUK** | Transkripsi (Biologi) | Pemahaman tentang reaksi polimerisasi secara kimia merupakan prasyarat untuk memahami mekanisme pembentukan RNA dalam proses transkripsi biologis. |
| LB079 | Bioteknologi Modern (Biologi) | **PRASYARAT_UNTUK** | DNA (Asam 2-Deoksiribonukleat) (Kimia) | Pemahaman struktur DNA dari Kimia adalah prasyarat untuk memahami dasar teknologi rekayasa genetika dalam Bioteknologi Modern. |
| LB080 | Gen (Biologi) | **APLIKASI_DARI** | Nukleotida (Kimia) | Konsep gen dalam biologi merupakan penerapan dari konsep nukleotida kimia sebagai unit penyusun urutan informasi genetik. |
| LB081 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Pembelahan Sel (Biologi) | Pemahaman struktur DNA dari Kimia adalah prasyarat untuk memahami replikasi dan distribusi materi genetik selama pembelahan sel di Biologi. |
| LB082 | Senyawa Organik (Kimia) | **PRASYARAT_UNTUK** | Teori Evolusi Kimia (Biologi) | Pemahaman senyawa organik dari Kimia adalah dasar untuk memahami pembentukan senyawa tersebut dalam Teori Evolusi Kimia di Biologi. |
| LB083 | Fotosintesis (Biologi) | **MEMPERDALAM** | Karbohidrat (Sakarida) (Kimia) | Konsep karbohidrat dari kimia memperdalam pemahaman tentang produk utama yang dihasilkan dari fotosintesis. |
| LB084 | Energi Aktivasi (Biologi) | **BERKAITAN_DENGAN** | Spontanitas Reaksi Elektrokimia (Kimia) | Energi aktivasi berkaitan dengan laju reaksi, sedangkan spontanitas reaksi elektrokimia berkaitan dengan kelayakan termodinamika. |
| LB085 | Energi Aktivasi (Biologi) | **MEMPERDALAM** | reaksi spontan (Kimia) | Energi aktivasi (Biologi/Kimia) memperdalam pemahaman mengapa reaksi spontan (Kimia) mungkin memerlukan pemicu atau katalis untuk laju signifikan. |
| LB086 | Holoenzim (Biologi) | **PRASYARAT_UNTUK** | Identifikasi Gugus Fungsi (Kimia) | Pemahaman gugus fungsi dari Kimia adalah prasyarat untuk memahami struktur kimia gugus prostetik dalam holoenzim di Biologi. |
| LB087 | Reaksi Elektrokimia (Kimia) | **MEMPERDALAM** | Teori Evolusi Kimia (Biologi) | Reaksi elektrokimia memperdalam pemahaman bagaimana energi listrik halilintar memicu pembentukan senyawa organik dalam teori evolusi kimia. |
| LB088 | Energi Aktivasi (Biologi) | **MEMPERDALAM** | Reaksi Esterifikasi (Kimia) | Konsep energi aktivasi menjelaskan mengapa reaksi kimia, termasuk esterifikasi, membutuhkan energi awal untuk berlangsung. |
| LB089 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Holoenzim (Biologi) | Pemahaman tentang asam amino (Kimia) adalah prasyarat untuk memahami struktur protein (apoenzim) yang merupakan bagian dari holoenzim (Biologi). |
| LB090 | Fotosintesis (Biologi) | **MEMPERDALAM** | Sel Volta (Kimia) | Konsep sel volta dalam kimia dapat memperdalam pemahaman tentang bagaimana transfer elektron dan reaksi redoks berperan dalam konversi energi pada fotosintesis. |
| LB091 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Translasi (Biologi) | Pemahaman struktur kimia DNA adalah prasyarat untuk memahami bagaimana informasi genetiknya diekspresikan melalui proses translasi dalam biologi. |
| LB092 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Gametogenesis (Biologi) | Konsep DNA dari Kimia adalah prasyarat fundamental untuk memahami materi genetik yang direplikasi dan diwariskan selama gametogenesis di Biologi. |
| LB093 | Asam Amino (Kimia) | **PRASYARAT_UNTUK** | Teori Evolusi Kimia (Biologi) | Konsep asam amino dari Kimia merupakan dasar untuk memahami perannya sebagai produk awal dalam Teori Evolusi Kimia di Biologi. |
| LB094 | Setengah Reaksi (Kimia) | **MEMPERDALAM** | Siklus Krebs (Biologi) | Pemahaman setengah reaksi dalam kimia membantu menganalisis dan memperdalam pemahaman reaksi redoks yang terjadi pada tahapan Siklus Krebs. |
| LB096 | Bioremediasi (Biologi) | **APLIKASI_DARI** | Degradasi Plastik (Kimia) | Bioremediasi adalah aplikasi biologis dari konsep degradasi plastik, khususnya yang terjadi secara biologis. |
| LB099 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **SAMA_DENGAN** | DNA (Deoxyribonucleic Acid) (Biologi) | Kedua konsep merujuk pada molekul DNA yang sama, meskipun dijelaskan dari perspektif kimia dan biologi. |
| LB100 | Polimer Alam (Kimia) | **PRASYARAT_UNTUK** | Transkripsi (Biologi) | Konsep polimer alam dari Kimia adalah prasyarat untuk memahami struktur DNA dan RNA yang berperan penting dalam proses transkripsi di Biologi. |
| LB101 | Fosforilasi Oksidatif (Biologi) | **MEMPERDALAM** | Setengah Reaksi (Kimia) | Konsep setengah reaksi (Kimia) memperdalam pemahaman tentang komponen oksidasi dan reduksi dalam setiap langkah fosforilasi oksidatif (Biologi). |
| LB102 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Transkripsi (Biologi) | Pemahaman struktur DNA dari Kimia adalah prasyarat untuk memahami bagaimana DNA berfungsi sebagai cetakan dalam proses transkripsi di Biologi. |
| LB103 | Biodegradasi (Biologi) | **MEMPERDALAM** | Degradasi Plastik (Kimia) | Konsep Biodegradasi dalam biologi memperdalam pemahaman tentang salah satu mekanisme utama Degradasi Plastik dalam kimia, yaitu penguraian secara biologis. |
| LB106 | Reaksi Oksidasi Senyawa Organik (Kimia) | **APLIKASI_DARI** | Siklus Krebs (Biologi) | Siklus Krebs dalam biologi adalah penerapan prinsip-prinsip reaksi oksidasi senyawa organik yang dipelajari dalam kimia untuk menghasilkan energi. |
| LB107 | Metabolisme (Biologi) | **MEMPERDALAM** | reaksi spontan (Kimia) | Konsep reaksi spontan dalam Kimia, yang terkait dengan termodinamika, memperdalam pemahaman tentang arah dan energi reaksi dalam proses metabolisme Biologi. |
| LB108 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Gen (Biologi) | Pemahaman tentang struktur kimia DNA adalah prasyarat untuk memahami gen sebagai segmen fungsional dari DNA. |
| LB109 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Epigenetik (Biologi) | Pemahaman struktur dan sifat kimia DNA dari perspektif kimia adalah prasyarat untuk memahami bagaimana perubahan epigenetik memengaruhi fungsi DNA. |
| LB110 | Etanol (Kimia) | **BERKAITAN_DENGAN** | Produksi Tempe (Biologi) | Etanol adalah produk fermentasi alkohol, sementara produksi tempe adalah contoh lain dari proses fermentasi yang melibatkan mikroorganisme. |
| LB111 | Biodegradable Plastic (Kimia) | **MEMPERDALAM** | Bioremediasi (Biologi) | Bioremediasi (Biologi) memperdalam pemahaman tentang bagaimana plastik biodegradable (Kimia) dapat terurai melalui proses biologis. |
| LB114 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **MEMPERDALAM** | Materi Genetik (Biologi) | Konsep DNA dalam Kimia memperdalam pemahaman tentang struktur molekuler salah satu komponen utama Materi Genetik dalam Biologi. |
| LB116 | Fosforilasi Oksidatif (Biologi) | **PRASYARAT_UNTUK** | Oksidasi (Kimia) | Pemahaman konsep oksidasi dari kimia adalah prasyarat untuk memahami reaksi kehilangan elektron dalam fosforilasi oksidatif. |
| LB117 | DNA (Asam 2-Deoksiribonukleat) (Kimia) | **PRASYARAT_UNTUK** | Sintesis Protein (Biologi) | Pemahaman struktur kimia DNA dari Kimia adalah prasyarat untuk memahami bagaimana DNA berfungsi dalam sintesis protein di Biologi. |

### Fisika <-> Kimia

| ID | Konsep A (mapel) | Relasi diusulkan | Konsep B (mapel) | Penjelasan |
|---|---|---|---|---|
| LB005 | Potensial Elektrode (Kimia) | **APLIKASI_DARI** | muatan kapasitor keping sejajar dan hubungan medan dan potensial listrik pelat paralel (Fisika) | Konsep potensial elektrode (Kimia) merupakan aplikasi spesifik dari prinsip-prinsip potensial listrik dan medan listrik (Fisika) dalam konteks reaksi kimia. |
| LB008 | alat ukur listrik (Fisika) | **PRASYARAT_UNTUK** | ggl sel (Kimia) | Pengetahuan alat ukur listrik dari Fisika adalah prasyarat untuk mengukur dan memahami gaya gerak listrik (ggl) sel dalam Kimia. |
| LB013 | Elektrode Hidrogen Standar (Kimia) | **APLIKASI_DARI** | Potensial Listrik (Fisika) | Elektrode Hidrogen Standar (Kimia) adalah aplikasi spesifik dari konsep potensial listrik (Fisika) sebagai titik acuan dalam skala potensial elektrode. |
| LB014 | Potensial Listrik (Fisika) | **MEMPERDALAM** | Reaksi Elektrokimia (Kimia) | Konsep potensial listrik dari Fisika memberikan dasar pemahaman tentang voltase atau energi listrik yang terlibat dalam reaksi elektrokimia di Kimia. |
| LB016 | Potensial Listrik (Fisika) | **MEMPERDALAM** | Sel Volta (Kimia) | Konsep potensial listrik (Fisika) memperdalam pemahaman tentang bagaimana sel Volta (Kimia) menghasilkan energi listrik dalam bentuk tegangan. |
| LB017 | Hukum II Kirchhoff (Hukum Tegangan Kirchhoff) (Fisika) | **PRASYARAT_UNTUK** | ggl sel (Kimia) | Hukum II Kirchhoff (Fisika) adalah prasyarat untuk memahami kontribusi ggl sel (Kimia) pada tegangan dan arus dalam rangkaian listrik. |
| LB022 | Fungsi Kerja Logam (W0) (Fisika) | **BERKAITAN_DENGAN** | Pelapisan Logam (Electroplating) (Kimia) | Kedua konsep berkaitan dengan sifat-sifat logam dan perilaku elektron, namun tidak ada hubungan prasyarat atau aplikasi langsung. |
| LB026 | Potensial Elektrode Standar (Kimia) | **APLIKASI_DARI** | Potensial Listrik (Fisika) | Potensial Elektrode Standar adalah nilai terukur dari Potensial Elektrode, yang merupakan aplikasi dari konsep Potensial Listrik dalam konteks kimia. |
| LB028 | Sistem Elektronika (Fisika) | **BERKAITAN_DENGAN** | sel elektrokimia (Kimia) | Kedua konsep ini berkaitan dengan listrik, namun sistem elektronika berfokus pada sirkuit, sementara sel elektrokimia pada reaksi kimia yang menghasilkan listrik. |
| LB049 | Klasifikasi Semikonduktor (Fisika) | **BERKAITAN_DENGAN** | Polimer Anorganik (Kimia) | Beberapa polimer anorganik dapat menunjukkan sifat semikonduktor, sehingga kedua konsep ini berkaitan dalam konteks material. |
| LB061 | Gaya Gerak Listrik (GGL) Sel Elektrokimia (Kimia) | **APLIKASI_DARI** | Potensial Listrik (Fisika) | Gaya Gerak Listrik (GGL) Sel Elektrokimia (Kimia) adalah penerapan atau manifestasi spesifik dari konsep potensial listrik (Fisika) dalam konteks sel elektrokimia. |
| LB063 | Arus Listrik (Fisika) | **APLIKASI_DARI** | Elektroforesis (Kimia) | Elektroforesis (Kimia) adalah penerapan konsep arus listrik (Fisika) untuk memisahkan partikel koloid bermuatan. |
| LB072 | Arus Listrik (Fisika) | **APLIKASI_DARI** | Pelapisan Logam (Electroplating) (Kimia) | Pelapisan logam (electroplating) dalam Kimia adalah aplikasi langsung dari konsep arus listrik yang dipelajari dalam Fisika. |
| LB074 | alat ukur listrik (Fisika) | **PRASYARAT_UNTUK** | sel elektrokimia (Kimia) | Konsep alat ukur listrik dari Fisika adalah prasyarat untuk mengukur dan menganalisis kinerja sel elektrokimia dalam Kimia. |
| LB076 | Potensial Elektrode (Kimia) | **APLIKASI_DARI** | Potensial Listrik (Fisika) | Potensial Elektrode dalam kimia adalah manifestasi spesifik dari konsep Potensial Listrik yang lebih umum dalam fisika, terkait perbedaan tegangan pada elektroda. |
| LB095 | alat ukur listrik (Fisika) | **PRASYARAT_UNTUK** | elektrolit (Kimia) | Pengetahuan alat ukur listrik dari Fisika adalah prasyarat untuk mengukur dan memahami sifat konduktivitas elektrolit dalam Kimia. |
| LB097 | Defleksi Gerak Muatan (Fisika) | **PRASYARAT_UNTUK** | Pelapisan Logam (Electroplating) (Kimia) | Konsep defleksi gerak muatan dalam fisika adalah prasyarat untuk memahami pergerakan ion dan mekanisme dasar pelapisan logam secara elektrokimia. |
| LB098 | alat ukur listrik (Fisika) | **BERKAITAN_DENGAN** | jembatan garam (Kimia) | Alat ukur listrik dan jembatan garam berkaitan karena keduanya merupakan komponen atau alat yang digunakan dalam studi sel elektrokimia. |
| LB104 | Potensial Listrik (Fisika) | **PRASYARAT_UNTUK** | Spontanitas Reaksi Elektrokimia (Kimia) | Konsep potensial listrik dari fisika adalah prasyarat untuk memahami spontanitas reaksi elektrokimia yang ditentukan oleh potensial sel. |
| LB105 | alat ukur listrik (Fisika) | **PRASYARAT_UNTUK** | elektrolisis (Kimia) | Pengetahuan alat ukur listrik dari Fisika adalah prasyarat untuk melakukan dan menganalisis eksperimen elektrolisis dalam Kimia. |
| LB115 | Defleksi Gerak Muatan (Fisika) | **PRASYARAT_UNTUK** | Elektroforesis (Kimia) | Konsep Defleksi Gerak Muatan dalam fisika adalah prasyarat untuk memahami prinsip kerja Elektroforesis dalam kimia yang memisahkan partikel bermuatan. |
